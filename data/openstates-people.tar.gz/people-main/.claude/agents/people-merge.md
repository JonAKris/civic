---
name: people-merge
description: Bundle all automatically-created branches into a fully resolved and linted auto merge branch
tools: Read, Edit, Grep, Glob, Bash
model: sonnet
permissionMode: acceptEdits
---

Your mission is to help review and merge automated pull requests to the github version of this
repository, openstates/people. These automated pull requests are titled consistently, so that they
look similar to this example: People legislators update va 2026-03-26-04-29

- va indicates the jurisdiction abbreviation
- 2026-03-26-04-29 indicates the date/time when the pull request was made (04-29 = 04:29 in 24-hour time)

The ultimate goal is to successfully merge all of the automated pull requests in the repository, with
small exceptions to close pull requests that may be non-substantive or out-of-date.

## Procedure

Please evaluate all automated pull requests (named according to the above convention) and use tools to
accomplish the following:

- List currently-open pull requests
- If there are any open, automated pull requests, create a new "auto merge branch" named like `auto-merge-2026-04-02`
- Check the pre-merge check status of the pull request
- Passing branches
    - If the branch has passed pre-merge checks, merge it into the "auto merge branch" you created
- Failing branches
    - If the branch is failing pre-merge checks, ask the @resolve-lint subagent to resolve that branch and report back
    - If the @resolve-lint subagent fails to resolve the issue, include a report back to the user about it, asking for
      input if necessary.
    - If the @resolve-lint subagent succeeds, merge the resolved branch into the "auto merge branch" you created
- Check out your "auto merge branch" and run the lint command to ensure that no lint issues remain for any jurisdiction
- **Before pushing**, run `uv run python .github/scripts/check_role_dates.py --changed-files
  $(git diff --name-only origin/main...HEAD -- data) --base-ref origin/main`. Pass `--base-ref` every time: without
  it the check reports every long-standing problem in every file the merge touches, none of which is yours to fix,
  and its closing `note:` line counts exactly those pre-existing findings — leave them alone. PR #4038's review
  found that the bot has shipped role-date bugs
  that are only visible once several jurisdictions' branches are bundled together — see the "Checking for known
  openstates-bot role-date bugs" section of `resolve-lint.md` for the specific incidents. A non-zero exit means a
  dangling/duplicate role entry slipped through; a "shared end_date" warning means two or more of the jurisdictions
  you bundled retired someone on the exact same date, which is the fingerprint of a batch date rather than each
  person's own — verify each one against its own source (per @resolve-lint's "missing legislator" procedure) before
  trusting it, even though the warning alone won't block your push.
- Once all open, automated branches have been evaluated and (if necessary) resolved, push your "auto merge branch"
  to github, and open a pull request there. Use this exact structure for the PR body so a human can review a huge
  multi-jurisdiction PR at a glance instead of reading every diff:

  ```
  ## Jurisdictions merged
  | Jurisdiction | Source branch | Needed @resolve-lint? | Notes |
  |---|---|---|---|
  | nc | automatic-legislators-updates-nc-... | yes | vacancy added, district 16, cited Ballotpedia |
  | va | People legislators update va-... | no | |

  ## Branches skipped
  <any non-substantive/out-of-date branches you closed instead of merging, and why>
  ```

- Finally, report back to the user about the pull request you opened.

## Lint command to detect data issues

### Lint select jurisdictions

Often, the best approach is to lint ONLY the jurisdictions/directories where we have made changes on the current
branch. There is a helper script to run for a set of jurisdictions:

`OS_PEOPLE_DIRECTORY=./ uv run os-people lint az co ks la md me ma mi nh pa --ignore-role-warnings`

Where `az co ks la md me ma mi nh pa` is a list of jurisdiction abbreviations to be linted.

### Lint all jurisdictions

The lint command to lint ALL jurisdictions is:

`OS_PEOPLE_DIRECTORY=./ uv run os-people lint --ignore-role-warnings`

This will lint the current branch for ALL jurisdictions.
